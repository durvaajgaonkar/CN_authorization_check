# TCP Multithreaded FTP Client-Server

## Overview
This project implements a simple multithreaded FTP client-server application using TCP sockets in C. The server listens for incoming connections and allows clients to download files.

## Requirements
- MinGW or Cygwin installed on your Windows machine.
- Basic understanding of C programming and socket programming.

## How to Compile
1. Open your terminal (Cygwin or MinGW).
2. Navigate to your project directory.
3. Run `make` to compile the server and client.

## How to Run
1. First, run the server:
2. Then, run the client in another terminal:
3. Enter the filename you want to download when prompted.

## Note
Importantly make sure that the file you want to download is in the same directory as the server.
