# import socket
# import tkinter as tk
# from tkinter import messagebox

# SERVER_ADDRESS = '127.0.0.1'
# SERVER_PORT = 8080
# BUFFER_SIZE = 1024

# class FileClient:
#     def __init__(self, master):
#         self.master = master
#         master.title("File Download Client")
#         master.geometry("400x300")
#         master.config(bg="#2E8B57")

#         # Username Label and Entry
#         self.username_label = tk.Label(master, text="Username:", bg="#2E8B57", fg="#FFFFFF")
#         self.username_label.pack(pady=5)
#         self.username_entry = tk.Entry(master, width=30)
#         self.username_entry.pack(pady=5)

#         # Password Label and Entry
#         self.password_label = tk.Label(master, text="Password:", bg="#2E8B57", fg="#FFFFFF")
#         self.password_label.pack(pady=5)
#         self.password_entry = tk.Entry(master, show='*', width=30)
#         self.password_entry.pack(pady=5)

#         # Filename Label and Entry
#         self.label = tk.Label(master, text="Enter filename to download:", bg="#2E8B57", fg="#FFFFFF")
#         self.label.pack(pady=10)
#         self.filename_entry = tk.Entry(master, width=30)
#         self.filename_entry.pack(pady=5)

#         self.download_button = tk.Button(master, text="Download File", command=self.download_file, bg="#FFD700", fg="#000000")
#         self.download_button.pack(pady=20)

#         self.exit_button = tk.Button(master, text="Exit", command=master.quit, bg="#FF6347", fg="#FFFFFF")
#         self.exit_button.pack(pady=5)

#     def download_file(self):
#         username = self.username_entry.get().strip()
#         password = self.password_entry.get().strip()
#         filename = self.filename_entry.get().strip()

#         if username and password and filename:
#             try:
#                 with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
#                     print("Connecting to server...")
#                     sock.connect((SERVER_ADDRESS, SERVER_PORT))
#                     print("Connected to server.")

#                     # Send username and password for authentication
#                     sock.sendall(f"{username}\n".encode())
#                     print("Sent username.")
#                     sock.sendall(f"{password}\n".encode())
#                     print("Sent password.")

#                     # Receive authentication response
#                     auth_response = sock.recv(BUFFER_SIZE).decode().strip()
#                     print("Authentication response:", auth_response)
#                     if "Invalid" in auth_response:
#                         messagebox.showerror("Authentication Error", auth_response)
#                         return

#                     # Send filename
#                     sock.sendall(f"{filename}\n".encode())
#                     print(f"Requested file: {filename}")

#                     # Receiving the file
#                     with open(filename, 'wb') as file:
#                         print("Starting file download...")
#                         while True:
#                             data = sock.recv(BUFFER_SIZE)
#                             if not data:
#                                 break
#                             file.write(data)
#                     messagebox.showinfo("Success", f"File '{filename}' downloaded successfully!")
#             except Exception as e:
#                 messagebox.showerror("Error", f"Failed to download file: {e}")
#         else:
#             messagebox.showwarning("Input Error", "Please enter username, password, and filename.")

# if __name__ == "__main__":
#     root = tk.Tk()
#     app = FileClient(root)
#     root.mainloop()


import socket
import tkinter as tk
from tkinter import messagebox

SERVER_ADDRESS = '127.0.0.1'
SERVER_PORT = 8080
BUFFER_SIZE = 1024

class FileClient:
    def __init__(self, master):
        self.master = master
        master.title("File Download Client")
        master.geometry("400x300")
        master.config(bg="#2E8B57")

        # Filename Label and Entry
        self.label = tk.Label(master, text="Enter filename to download:", bg="#2E8B57", fg="#FFFFFF")
        self.label.pack(pady=10)
        self.filename_entry = tk.Entry(master, width=30)
        self.filename_entry.pack(pady=5)

        self.download_button = tk.Button(master, text="Download File", command=self.download_file, bg="#FFD700", fg="#000000")
        self.download_button.pack(pady=20)

        self.exit_button = tk.Button(master, text="Exit", command=master.quit, bg="#FF6347", fg="#FFFFFF")
        self.exit_button.pack(pady=5)

    def download_file(self):
        filename = self.filename_entry.get().strip()

        if filename:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                    print("Connecting to server...")
                    sock.connect((SERVER_ADDRESS, SERVER_PORT))
                    print("Connected to server.")

                    # Send the filename to request
                    sock.sendall(f"{filename}\n".encode())
                    print(f"Requested file: {filename}")

                    # Receiving the file
                    with open(filename, 'wb') as file:
                        print("Starting file download...")
                        while True:
                            data = sock.recv(BUFFER_SIZE)
                            if not data:
                                break
                            file.write(data)
                    messagebox.showinfo("Success", f"File '{filename}' downloaded successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to download file: {e}")
        else:
            messagebox.showwarning("Input Error", "Please enter a filename.")

if __name__ == "__main__":
    root = tk.Tk()
    app = FileClient(root)
    root.mainloop()
