// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>
// #include <winsock2.h>
// #include <windows.h>

// #define PORT 8080
// #define BUFFER_SIZE 1024

// // Define your desired username and password
// #define USERNAME "durva"
// #define PASSWORD "durva"

// DWORD WINAPI clientHandler(LPVOID socket_desc) {
//     SOCKET client_socket = *(SOCKET*)socket_desc;
//     char buffer[BUFFER_SIZE];
//     int bytes_received;

//     // Request username from the client
//     send(client_socket, "Enter username: ", strlen("Enter username: "), 0);
//     bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);

//     // Ensure null termination
//     buffer[bytes_received - 1] = '\0';  // Remove newline
//     printf("Received username: '%s'\n", buffer);  // Debug output

//     // Validate username
//     if (strcmp(buffer, USERNAME) != 0) {
//         send(client_socket, "Invalid username.", strlen("Invalid username."), 0);
//         closesocket(client_socket);
//         free(socket_desc);
//         return 0;
//     }

//     // Request password from the client
//     send(client_socket, "Enter password: ", strlen("Enter password: "), 0);
//     bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);

//     // Ensure null termination
//     buffer[bytes_received - 1] = '\0';  // Remove newline
//     printf("Received password: '%s'\n", buffer);  // Debug output

//     // Validate password
//     if (strcmp(buffer, PASSWORD) != 0) {
//         send(client_socket, "Invalid password.", strlen("Invalid password."), 0);
//         closesocket(client_socket);
//         free(socket_desc);
//         return 0;
//     }

//     send(client_socket, "Authentication successful. Enter filename to download: ", strlen("Authentication successful. Enter filename to download: "), 0);
//     bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
//     buffer[bytes_received - 1] = '\0';  // Remove newline

//     // Open the file for reading
//     FILE *file = fopen(buffer, "rb");
//     if (file == NULL) {
//         send(client_socket, "ERROR", strlen("ERROR"), 0);
//         printf("File not found: %s\n", buffer);
//     } else {
//         // Send the file to the client
//         while ((bytes_received = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
//             send(client_socket, buffer, bytes_received, 0);
//         }
//         fclose(file);
//         printf("File sent: %s\n", buffer);
//     }

//     closesocket(client_socket);
//     free(socket_desc);
//     return 0;
// }

// int main() {
//     WSADATA wsa;
//     SOCKET server_socket, client_socket;
//     struct sockaddr_in server_addr, client_addr;
//     int addr_len = sizeof(client_addr);

//     WSAStartup(MAKEWORD(2, 2), &wsa);

//     server_socket = socket(AF_INET, SOCK_STREAM, 0);
//     server_addr.sin_family = AF_INET;
//     server_addr.sin_addr.s_addr = INADDR_ANY;
//     server_addr.sin_port = htons(PORT);

//     bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr));
//     listen(server_socket, 5);
//     printf("Server listening on port %d...\n", PORT);

//     while (1) {
//         client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &addr_len);
//         printf("Connection accepted.\n");

//         SOCKET* new_sock = malloc(sizeof(SOCKET));
//         *new_sock = client_socket;

//         // Create a thread to handle the client
//         CreateThread(NULL, 0, clientHandler, (void*)new_sock, 0, NULL);
//     }

//     closesocket(server_socket);
//     WSACleanup();
//     return 0;
// }


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <windows.h>

#define PORT 8080
#define BUFFER_SIZE 1024

DWORD WINAPI clientHandler(LPVOID socket_desc) {
    SOCKET client_socket = *(SOCKET*)socket_desc;
    char buffer[BUFFER_SIZE];
    int bytes_received;

    // Request the filename from the client
    send(client_socket, "Enter filename to download: ", strlen("Enter filename to download: "), 0);
    bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
    buffer[bytes_received - 1] = '\0';  // Remove newline

    // Open the file for reading
    FILE *file = fopen(buffer, "rb");
    if (file == NULL) {
        send(client_socket, "ERROR", strlen("ERROR"), 0);
        printf("File not found: %s\n", buffer);
    } else {
        // Send the file to the client
        while ((bytes_received = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
            send(client_socket, buffer, bytes_received, 0);
        }
        fclose(file);
        printf("File sent: %s\n", buffer);
    }

    closesocket(client_socket);
    free(socket_desc);
    return 0;
}

int main() {
    WSADATA wsa;
    SOCKET server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    int addr_len = sizeof(client_addr);

    WSAStartup(MAKEWORD(2, 2), &wsa);

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr));
    listen(server_socket, 5);
    printf("Server listening on port %d...\n", PORT);

    while (1) {
        client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &addr_len);
        printf("Connection accepted.\n");

        SOCKET* new_sock = malloc(sizeof(SOCKET));
        *new_sock = client_socket;

        // Create a thread to handle the client
        CreateThread(NULL, 0, clientHandler, (void*)new_sock, 0, NULL);
    }

    closesocket(server_socket);
    WSACleanup();
    return 0;
}
